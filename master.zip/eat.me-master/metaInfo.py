class metaInfo():
	def __init__(self, cuisine):
		self.cuisine = cuisine

	